 <!-- footer section ends  -->
 <div class ="footer">
       <div class="wrapper">
           <p class = "text-center">FOOD PANDA BY- <a class ="anchortag_color" href="#"> huzaifa jiwani </a></p>
        </div>
       </div>
       <!-- footer section ends  --> 

    </body>
</html>