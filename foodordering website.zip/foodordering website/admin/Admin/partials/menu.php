<?php include("../config/constants.php") ?>

<html>
    <head>
        <title>ADMIN PANNEL FOR FOOOD DELIVERY</title>
        <link rel="stylesheet" href="../css/Admin.css">
    </head>

    <body>
       <!-- menu section starts  -->
       <div class ="menu text-center">
           <div class="wrapper">
               <ul>
                   <li><a href="manage-admin.php">Admin</a></li>
                   <li><a href="manage-restaurants.php">Restaurants</a></li><!-- restaurants section  -->
                   <li><a href="manage-dishes.php">Dishes</a></li><!-- food section  -->
                   <li><a href="manage-deal.php">deal</a></li><!-- DEAL section  -->
                   <li><a href="manage-customer.php">Users</a></li><!-- food section  -->\
               </ul>
           </div>
       </div>
       <!-- menu section ends  -->
